package com.av.cara.model;

public class CarNullClass extends Car{
}
