package com.av.cara.model;

public class LotteryNullClass extends Lottery{
}
