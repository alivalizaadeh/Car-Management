package com.av.cara.model;

public class PersonNullClass extends Person{
}
