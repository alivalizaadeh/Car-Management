package com.av.cara.request;


public record LotteryRequest(
        String personNationalCode ,
        String carBuildNumber
) {
}
