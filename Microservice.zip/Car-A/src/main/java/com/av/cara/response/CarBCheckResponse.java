package com.av.cara.response;

import com.av.cara.model.Lottery;

public record CarBCheckResponse(Lottery lottery) {
}
