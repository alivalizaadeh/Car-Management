package com.av.carb.model;

public class CarNullClass extends Car{
}
