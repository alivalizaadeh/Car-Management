package com.av.carb.model;

public class LotteryNullClass extends Lottery{
}
