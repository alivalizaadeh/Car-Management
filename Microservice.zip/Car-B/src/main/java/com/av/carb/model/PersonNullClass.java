package com.av.carb.model;

public class PersonNullClass extends Person{
}
