package com.av.carb.request;

public record LotteryRequest(
        String personNationalCode ,
        String carBuildNumber
) {
}
