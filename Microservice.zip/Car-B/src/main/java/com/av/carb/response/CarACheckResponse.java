package com.av.carb.response;

import com.av.carb.model.Lottery;

public record CarACheckResponse(Lottery lottery) {
}
